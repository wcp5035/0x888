

# About me
____________
 Hi there 👋
 - 😄 I'm 君惜, I'm a coder.
 - 🌱 I'm familiar with Vue, React, JavaScript/- TypeScript/Nodejs, Python.
- 🔭 I'm currently doing front-end development 
- for an Internet company.
____________
#Contact me
- website: https://xinlei3166.com
- email: xinlei3166@gmail.com
- addr: Beijing, China

Open source project
click here to view the project

github stats for xinlei3166
Sponsor
如果感觉对您有帮助，请作者喝杯咖啡吧，请注明您的名字或者昵称，方便作者感谢。

微信	支付宝
	