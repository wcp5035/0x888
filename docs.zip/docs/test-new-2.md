# 新文章测试2

This page demonstrates some of the built-in markdown extensions provided by VitePress.
