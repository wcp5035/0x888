# Bitget－KYC 账户转移⽅法

一起交易，共享收益
立即注册，与强者为伍！
![](https://m2492468.695354.xyz/img/2025/01/02/5js9xc.png)


以下步骤可将原有Bitget账户的kyc信息移到使用社区链接注册的新Bitget账户,从而获得全网
最高返佣（交易所最高自动返佣比例20% + 泄密狗额外手动返佣20%）

- 1、登录现有Bitget账号，点击头像.
![](https://m2492468.695354.xyz/img/2025/01/02/6vzbx7.png)
![](https://m2492468.695354.xyz/img/2025/01/02/6wiotd.png)

- 2点击个人资料，下滑选择注销账户。完成后帐号的KYC信息将会释放，身份信息、手机号、邮
箱可用于绑定新的账号.
![](https://m2492468.695354.xyz/img/2025/01/02/6x02u2.png)
- 3使用社区邀请链接注册新的bitget账号，使用上述步骤释放的KYC信息进行认证。
 ![](https://m2492468.695354.xyz/img/2025/01/02/6x5el2.png)
     **
       [邀请直达](https://www.bitget.fit/zh-CN/referral/register?clacCode=W4K9JTC2&from=%2Fzh-CN%2Fevents%2Freferral-all-program&source=events&utmSource=PremierInviter)
 

 ::: details 或者直接填写邀请码
```js
W4K9JTC2
```
:::
