## Bitget－KYC 账户转移⽅
以下步骤可将原有Bybit账户的kyc信息移到使用社区链接注册的新Bybit账户,从而获得全网
最高返佣（泄密狗额外手动返佣30%）
- 1、登录现有Bybit账号，依次点击头像-账户 → 认证 → 身份转移 → 填写新账户信息 → 转移成功。
![](https://m2492468.695354.xyz/img/2025/01/02/7k401g.png)
![](https://m2492468.695354.xyz/img/2025/01/02/7k40l1.png)
![](https://m2492468.695354.xyz/img/2025/01/02/7k49br.png)
![](https://m2492468.695354.xyz/img/2025/01/02/7k48qq.png)
- 2使用社区邀请链接注册新的Bybit账号，填入上述步骤中。
![](https://m2492468.695354.xyz/img/2025/01/02/7k4gvx.png)

  **
       [邀请直达](https://www.bybitglobal.com/invite?ref=REW961Y)
 

 ::: details 或者直接填写邀请码
```js
REW961Y
```
:::

